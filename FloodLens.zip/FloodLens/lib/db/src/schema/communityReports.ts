import {
  doublePrecision,
  pgTable,
  text,
  timestamp,
  uuid,
} from "drizzle-orm/pg-core";

export const communityReportsTable = pgTable("community_reports", {
  id: uuid("id").defaultRandom().primaryKey(),
  category: text("category").notNull(),
  district: text("district").notNull(),
  locality: text("locality").notNull(),
  description: text("description").notNull(),
  latitude: doublePrecision("latitude"),
  longitude: doublePrecision("longitude"),
  observedAt: timestamp("observed_at", { withTimezone: true }),
  status: text("status").notNull().default("submitted"),
  submittedAt: timestamp("submitted_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type CommunityReportRecord = typeof communityReportsTable.$inferSelect;
export type NewCommunityReport = typeof communityReportsTable.$inferInsert;
