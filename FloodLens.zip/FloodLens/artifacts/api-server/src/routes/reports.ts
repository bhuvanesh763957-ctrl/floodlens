import {
  and,
  count,
  countDistinct,
  desc,
  eq,
  inArray,
  sql,
} from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  communityReportsTable,
  db,
  type CommunityReportRecord,
} from "@workspace/db";
import {
  CreateReportBody,
  CreateReportResponse,
  GetDashboardSummaryResponse,
  GetReportParams,
  GetReportResponse,
  ListReportsQueryParams,
  ListReportsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function toPublicReport(report: CommunityReportRecord) {
  return {
    ...report,
    verificationStatus: report.status === "verified" ? "verified" : "unverified",
  };
}

router.get("/dashboard/summary", async (_req, res): Promise<void> => {
  const activeStatuses = ["submitted", "under_review", "verified"];

  const [
    totalResult,
    awaitingResult,
    verifiedResult,
    locationsResult,
    roadClosuresResult,
  ] = await Promise.all([
    db.select({ value: count() }).from(communityReportsTable),
    db
      .select({ value: count() })
      .from(communityReportsTable)
      .where(
        inArray(communityReportsTable.status, ["submitted", "under_review"]),
      ),
    db
      .select({ value: count() })
      .from(communityReportsTable)
      .where(eq(communityReportsTable.status, "verified")),
    db
      .select({
        value: countDistinct(
          sql`(lower(${communityReportsTable.district}), lower(${communityReportsTable.locality}))`,
        ),
      })
      .from(communityReportsTable)
      .where(inArray(communityReportsTable.status, activeStatuses)),
    db
      .select({ value: count() })
      .from(communityReportsTable)
      .where(
        and(
          eq(communityReportsTable.category, "blocked_road"),
          inArray(communityReportsTable.status, activeStatuses),
        ),
      ),
  ]);

  res.json(
    GetDashboardSummaryResponse.parse({
      totalReports: totalResult[0]?.value ?? 0,
      awaitingVerification: awaitingResult[0]?.value ?? 0,
      verifiedActiveReports: verifiedResult[0]?.value ?? 0,
      affectedLocations: locationsResult[0]?.value ?? 0,
      reportedRoadClosures: roadClosuresResult[0]?.value ?? 0,
      activeOfficialWarnings: null,
      officialWarningsAvailable: false,
      districtsWithWeatherAlerts: null,
      weatherAlertsAvailable: false,
      generatedAt: new Date(),
    }),
  );
});

router.get("/reports", async (req, res): Promise<void> => {
  const parsed = ListReportsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const filters = [];
  if (parsed.data.district) {
    filters.push(
      sql`lower(${communityReportsTable.district}) = ${parsed.data.district.toLowerCase()}`,
    );
  }
  if (parsed.data.category) {
    filters.push(eq(communityReportsTable.category, parsed.data.category));
  }

  const query = db
    .select()
    .from(communityReportsTable)
    .orderBy(desc(communityReportsTable.submittedAt))
    .limit(parsed.data.limit);

  const reports =
    filters.length > 0
      ? await query.where(and(...filters))
      : await query;

  res.json(ListReportsResponse.parse(reports.map(toPublicReport)));
});

router.post("/reports", async (req, res): Promise<void> => {
  const parsed = CreateReportBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { latitude, longitude, observedAt, ...reportInput } = parsed.data;
  if ((latitude === undefined) !== (longitude === undefined)) {
    res.status(400).json({
      error: "Latitude and longitude must be provided together.",
    });
    return;
  }

  const [report] = await db
    .insert(communityReportsTable)
    .values({
      ...reportInput,
      district: reportInput.district.trim(),
      locality: reportInput.locality.trim(),
      description: reportInput.description.trim(),
      latitude: latitude ?? null,
      longitude: longitude ?? null,
      observedAt: observedAt ?? null,
    })
    .returning();

  if (!report) {
    res.status(500).json({ error: "The report could not be saved." });
    return;
  }

  res.status(201).json(CreateReportResponse.parse(toPublicReport(report)));
});

router.get("/reports/:id", async (req, res): Promise<void> => {
  const params = GetReportParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [report] = await db
    .select()
    .from(communityReportsTable)
    .where(eq(communityReportsTable.id, params.data.id))
    .limit(1);

  if (!report) {
    res.status(404).json({ error: "Report not found." });
    return;
  }

  res.json(GetReportResponse.parse(toPublicReport(report)));
});

export default router;
